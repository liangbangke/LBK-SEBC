```bash

node1  cdh01.cs1hypers.com  10.100.196.31 NN

node2  cdh02.cs1hypers.com  10.100.196.84 DN

node3  cdh03.cs1hypers.com  10.100.196.32 DN

node4  cdh04.cs1hypers.com  10.100.196.33 DN
 

```
