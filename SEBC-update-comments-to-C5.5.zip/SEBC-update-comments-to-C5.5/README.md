# <center>SEBC Courseware

This is the courseware for Cloudera's Services Enablement Boot Camp (SEBC). It is maintained in a private repository. Each student is made a collaborator on the first day of class they attend. It is solely intended for each student's personal use. 

Although billed as courseware, each student is encouraged to turn this content into a run book suitable for use on an engagement.




 updated for each delivery. It should be also updated with point-releases (e.g., C5.3.0, C5.4.0) that affect this course's content.

